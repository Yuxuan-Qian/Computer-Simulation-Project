import matplotlib.pyplot as plt
from Solar import Solar
from Planet import Planet_Beeman, Planet_Euler
import numpy as np


class Experiments(Solar):

    def __init__(self):
        super().__init__()
        Euler = Solar(algorithm=Planet_Euler)

        # some data needed for the following experiment
        self.r = np.zeros((len(self.bodies), self.niter, 2))
        self.period = [[],[],[],[],[],[]]
        self.totalE_B, self.totalE_E = [], []
        print('Please wait a minute...')

        # fetch data from each iteration
        for i in range(self.niter):

            # For Beeman method
            # update and store position
            for j in range(0, len(self.bodies)):
                self.bodies[j].updatePos(self.G, self.dt)
                self.r[j, i] = self.bodies[j].r

            #update velocities
            for j in range(0, len(self.bodies)):
                for k in range(0, len(self.bodies)):
                    if (j != k):
                        self.bodies[j].updateVel(self.G, self.dt, self.bodies[k])

            # keep track of time in earth years
            time = (i + 1) * self.dt
            # check year
            for j in range(0, len(self.bodies)):
                if (self.bodies[j].newYear()):
                    self.period[j].append(time)

            # convert energy to J
            self.totalE_B.append(self.energy()*(5.97219e+24 * 1.496e+11 * 1.496e+11) / (3.154e+7 * 3.154e+7))

            # Euler method
            # update position
            for j in range(0, len(Euler.bodies)):
                Euler.bodies[j].updatePos(Euler.G, Euler.dt)

            #update velocities
            for j in range(0, len(Euler.bodies)):
                for k in range(0, len(Euler.bodies)):
                    if (j != k):
                        Euler.bodies[j].updateVel(Euler.G, Euler.dt, Euler.bodies[k])

            self.totalE_E.append(Euler.energy()*(5.97219e+24 * 1.496e+11 * 1.496e+11) / (3.154e+7 * 3.154e+7))

    def orbital_periods(self):
        print('\n'+'Experiment for orbital periods:')

        for i in range(1, len(self.bodies)):

            # obtain periods for each circle
            for j in range(len(self.period[i])):
                if j < len(self.period[i])-1:
                    self.period[i][-j-1] -= self.period[i][-j-2]

            actual_period = 2 * np.pi * (self.r[i, 0, 0] ** (3 / 2)) / np.sqrt(self.G * self.bodies[0].m)

            # error is difference between two periods over actual period
            error = sum(abs(np.array(self.period[i])-actual_period))/len(self.period[i])
            print(f'For {self.bodies[i].name} Average error of period is {error*365:.2f} days')
            print(f' Percentage of error is {error / actual_period:%}', end='\n')

    def energy_conservation(self):
        energy = np.array(self.totalE_B)

        # ratio of difference between current total energy and initial total energy with initial energy
        ratio = abs((energy-energy[0])/energy[0])

        fig, ax = plt.subplots(figsize=(10, 6))
        x = np.arange(0, self.dt*self.niter, self.dt)
        ax.plot(x, ratio, 'r-')
        ax.plot(x, [0]*len(self.totalE_B), 'k-')
        ax.set_xlabel('Year', fontsize=15)
        ax.set_ylabel('Fluctuation rate of total energy', fontsize=15)
        ax.set_title('Energy conservation for Beeman method', fontsize=20)
        ax.set_ylim(-0.1e-6, 0.5e-6)

        plt.show()

    def compare_energy(self):
        energy_B = np.array(self.totalE_B)
        energy_E = np.array(self.totalE_E)

        # plot
        fig, ax = plt.subplots(figsize=(10, 6))
        x = np.arange(0, self.dt * self.niter, self.dt)
        ax.plot(x, abs((energy_E - energy_E[0])/energy_E[0]), 'r-', label='Euler Method')
        ax.plot(x, abs((energy_B-energy_B[0])/energy_B[0]), 'b-', label='Beeman Method')
        ax.plot(x, [0] * len(self.totalE_E), 'k-')
        ax.set_xlabel('Year', fontsize=15)
        ax.set_ylabel('Ratio of energy difference to initial energy', fontsize=15)
        ax.set_title('Energy conservation for Beeman and Euler method', fontsize=20)

        plt.legend()
        plt.show()

    def satellite_to_Mars(self, v):
        print('\n'+'Experiment for satellite to Mars:')
        print('You can close the animation whenever purple dot(satellite) '
              'close to red dot(Mars)')
        print(input('Just make sure you read the line above(Press Enter to proceed)'))

        # construct a new solar system and add satellite
        super().__init__()
        self.bodies.append(Planet_Beeman('Satellite', 1.71e-22, 1 + 0.001, 'purple'))
        self.bodies[-1].initialise(self.G, self.bodies[0])

        # initial velocity is the launch velocity plus velocity influenced by solar system
        self.bodies[-1].v += np.array(v)*365*24*3600/149597871

        # set a initial distance
        self.min_d = np.linalg.norm(self.bodies[4].r - self.bodies[-1].r)
        self.run()
        print(f'For v={v}, the closest distance is {round(self.min_d * 149.597871, 4)}M km, at time {self.t} years')

        # check whether satellite return
        super().__init__()
        self.bodies.append(Planet_Beeman('Satellite', 1.71e-22, 1 + 0.001, 'purple'))
        self.bodies[-1].initialise(self.G, self.bodies[0])
        self.bodies[-1].v += v
        print('Checking whether satellite returns...')

        for i in range(self.niter):
            # keep track of time in earth years
            time = (i + 1) * self.dt

            # update positions
            for j in range(0, len(self.bodies)):
                self.bodies[j].updatePos(self.G, self.dt)

            # take distance between satellite and Earth less than , and exculde the
            if np.linalg.norm(self.bodies[3].r - self.bodies[6].r) < 0.001:
                print(f'At {time} years , satellite return')

            # update velocities
            for j in range(0, len(self.bodies)):
                for k in range(0, len(self.bodies)):
                    if (j != k):
                        self.bodies[j].updateVel(self.G, self.dt, self.bodies[k])
        print(f'Finish checking for {time} years')

    def alignment(self):
        print('\n' + 'Experiment for Doomsday Planetary Alignment:')

        align = [0]
        for i in range(len(self.r[0])):
            time = (i + 1) * self.dt
            for j in range(2, 6):
                r1 = self.r[1][i] - self.r[0][i]
                r2 = self.r[j][i] - self.r[0][i]
                angle = np.arccos(r1 @ r2 / (np.linalg.norm(r1) * np.linalg.norm(r2)))

                # is angle is more than 5 degree
                if abs(angle) > np.pi*5/180 and abs(angle - np.pi) > np.pi*5/180:
                    break

                # when all angle within 5 degree
                if j == 5:

                    # filter out consecutive alignment
                    if (i*self.dt - align[-1]) > 0.01:
                        print(f'Alignment happens in {time}th year')
                        align.append(i * self.dt)
        print(f'{len(align)} alignments happens within 100 years')

    # not use in run.py, the results are in the report
    def alignment2(self, years):
        print('\n' + 'Experiment for Doomsday Planetary Alignment:')

        super().__init__()
        interval =[]
        for i in range(int(years/self.dt)):

            for j in range(0, 6):

                r1 = self.bodies[1].r - self.bodies[0].r
                if j > 1:
                    r2 = self.bodies[j].r - self.bodies[0].r
                    angle = np.arccos(r1 @ r2 / (np.linalg.norm(r1) * np.linalg.norm(r2)))

                    # if angle is more than 5 degree
                    if abs(angle) > np.pi*5/180 and abs(angle - np.pi) > np.pi*5/180:
                        break

                # when all angle within 5 degree
                if j == 5:

                    # exclude consecutive alignment and initial one
                    if (i*self.dt - sum(interval)) > 0.1:
                        interval.append(i*self.dt - sum(interval))
                        print(f'Alignment happens in {i * self.dt}th year')


            for j in range(0, len(self.bodies)):
                self.bodies[j].updatePos(self.G, self.dt)

            # then update velocities
            for j in range(0, len(self.bodies)):
                for k in range(0, len(self.bodies)):
                    if (j != k):
                        self.bodies[j].updateVel(self.G, self.dt, self.bodies[k])

        # plot a graph for time intervals
        fig, ax = plt.subplots()
        t = np.linspace(1, len(interval), len(interval))
        ax.plot(t, interval, 'kx')
        ax.set_title('Time intervals for alignments')
        ax.set_ylabel('Year')

        plt.show()

        print(f'{len(interval)+1} alignments happens within {years} years, '
              f'The average interval between alignments is {sum(interval) / len(interval)} years')


