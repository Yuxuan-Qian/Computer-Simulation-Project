from Experiments import Experiments
from Solar import Solar

def runSimulation():
    a = Solar()
    a.run()

def runExperiment():
    b = Experiments()
    b.orbital_periods()
    b.energy_conservation()
    b.compare_energy()
    b.satellite_to_Mars([11, 0])
    b.alignment()


runSimulation()
runExperiment()